async function test() {
    const payload = {
        event: "messages.upsert",
        data: {
            messages: [{
                key: { remoteJid: "51927507585@s.whatsapp.net", fromMe: false },
                message: { conversation: "hola bot" }
            }]
        }
    };

    try {
        console.log("Sending fake webhook to Vercel...");
        const res = await fetch("https://almacen-produccion-propia.vercel.app/api/bot/webhook", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        console.log("Status:", res.status);
        const text = await res.text();
        console.log("Response:", text);
    } catch (e) {
        console.error("Error:", e);
    }
}
test();
