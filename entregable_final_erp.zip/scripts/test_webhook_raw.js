async function testRaw() {
    // "webhookByEvents: false" usually sends an array of messages at root
    const payload = [{
        key: { remoteJid: "51927507585@s.whatsapp.net", fromMe: false },
        message: { conversation: "Prueba de Vercel (Formato Raw)" }
    }];

    try {
        console.log("Sending RAW fake webhook to Vercel...");
        const res = await fetch("https://almacen-produccion-propia.vercel.app/api/bot/webhook", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        console.log("HTTP Status:", res.status);
        const text = await res.text();
        console.log("Body:", text);

        if (text.includes('"status":"ignored"')) {
            console.log("❌ Vercel todavia esta con la version antigua...");
        } else {
            console.log("✅ Vercel ya se actualizo y proceso el mensaje!");
        }
    } catch (e) {
        console.error("Error:", e);
    }
}
testRaw();
