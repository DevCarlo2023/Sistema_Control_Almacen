const fs = require('fs');
async function reset() {
    const apiKey = "429683C4C977415CAAFCCE10F7D57E11";
    try {
        console.log("Logging out from Evolution...");
        const resLogout = await fetch("https://evolution-evolution-api.oesm5z.easypanel.host/instance/logout/carlo_bot_v2", {
            method: 'DELETE',
            headers: { apikey: apiKey }
        });
        console.log("Logout response:", resLogout.status);

        // Fetch new QR
        console.log("Fetching new QR immediately...");
        const resQR = await fetch("https://evolution-evolution-api.oesm5z.easypanel.host/instance/connect/carlo_bot_v2", {
            headers: { apikey: apiKey }
        });
        const data = await resQR.json();

        if (data.base64) {
            const base64Data = data.base64.replace(/^data:image\/png;base64,/, "");
            fs.writeFileSync("qr_whatsapp_latest.png", base64Data, 'base64');
            console.log("✅ New QR code saved to qr_whatsapp_latest.png");
        } else {
            console.log("No base64 image in response:", data);
        }
    } catch (e) {
        console.error("Error:", e.message);
    }
}
reset();
