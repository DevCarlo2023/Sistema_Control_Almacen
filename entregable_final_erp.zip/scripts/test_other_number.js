async function testOther() {
    const payload = [{
        key: { remoteJid: "123456789@s.whatsapp.net", fromMe: false },
        message: { conversation: "Mensaje desde numero externo" }
    }];

    try {
        console.log("Sending fake webhook from OTHER JID to Vercel...");
        const res = await fetch("https://almacen-produccion-propia.vercel.app/api/bot/webhook", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        console.log("Status:", res.status);
    } catch (e) { console.error(e) }
}
testOther();
