const { createClient } = require('@supabase/supabase-js');
async function run() {
    const supabase = createClient(
        "https://csmynzxymstfouivdsik.supabase.co",
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNzbXluenh5bXN0Zm91aXZkc2lrIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTk0MzM5OCwiZXhwIjoyMDg3NTE5Mzk4fQ.BeGva6qWk9zQNFDfa_Qz2POJrXxq-pe_sexAMhm89rU"
    );
    const { data, error } = await supabase.from('bot_sessions').select('jid, history, updated_at').order('updated_at', { ascending: false }).limit(2);
    console.log("Error:", error);
    console.log("Data:", JSON.stringify(data, null, 2));
}
run();
