const fs = require('fs');
async function getQR() {
    try {
        const url = "https://evolution-evolution-api.oesm5z.easypanel.host/instance/connect/carlo_bot_v2";
        const apiKey = "429683C4C977415CAAFCCE10F7D57E11";
        const res = await fetch(url, { headers: { apikey: apiKey } });
        const data = await res.json();

        fs.writeFileSync("qr_response_latest.json", JSON.stringify(data, null, 2));

        if (data.base64) {
            const base64Data = data.base64.replace(/^data:image\/png;base64,/, "");
            fs.writeFileSync("qr_whatsapp_latest.png", base64Data, 'base64');
            console.log("QR code saved to qr_whatsapp_latest.png");
        } else {
            console.log("No base64 image in response:", data);
        }
    } catch (e) {
        console.error("Error fetching QR:", e.message);
    }
}
getQR();
